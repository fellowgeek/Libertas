-- MySQL dump 10.13  Distrib 5.5.32, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: libertas
-- ------------------------------------------------------
-- Server version	5.5.32-0ubuntu0.13.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `post_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_title` varchar(255) DEFAULT NULL,
  `post_path` varchar(512) DEFAULT NULL,
  `post_path_hash` varchar(512) DEFAULT NULL,
  `post_text` text,
  `post_author` int(11) DEFAULT NULL,
  `post_categories` varchar(255) DEFAULT NULL,
  `post_keywords` varchar(255) DEFAULT NULL,
  `post_description` text,
  `post_tags` varchar(255) DEFAULT NULL,
  `post_layout` varchar(255) DEFAULT NULL,
  `post_theme` varchar(255) DEFAULT NULL,
  `post_views` int(11) DEFAULT NULL,
  `post_status` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `order_variable` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `OCDT` datetime DEFAULT NULL,
  `OCU` int(10) unsigned DEFAULT NULL,
  `OMDT` datetime DEFAULT NULL,
  `OMU` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',9256,'published','Lorem-Ipsum',7,0,'2013-08-03 17:19:56',0,NULL,NULL),(2,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',4365,'published','Lorem-Ipsum-1',6,0,'2013-08-03 17:20:15',0,NULL,NULL),(3,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',654,'published','Lorem-Ipsum-2',5,0,'2013-08-03 17:20:15',0,NULL,NULL),(4,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',1258,'published','Lorem-Ipsum-3',4,0,'2013-08-03 17:20:18',0,NULL,NULL),(5,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',2877,'published','Lorem-Ipsum-4',3,0,'2013-08-03 17:20:19',0,NULL,NULL),(6,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',5843,'published','Lorem-Ipsum-5',2,0,'2013-08-03 17:20:19',0,NULL,NULL),(7,'Lorem Ipsum','test/example/','c19ca5e3756d7ba8846e9abf743f6090','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.  Pug semiotics pour-over, keytar Brooklyn stumptown artisan Terry Richardson tofu fingerstache.  Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>',0,'stories,place holder','','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem,Ipsum,Dolor,Sit','','',4976,'published','Lorem-Ipsum-6',1,0,'2013-08-03 17:20:20',0,NULL,NULL);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-03 17:29:42
