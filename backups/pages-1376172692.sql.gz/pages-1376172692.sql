-- MySQL dump 10.13  Distrib 5.5.32, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: libertas
-- ------------------------------------------------------
-- Server version	5.5.32-0ubuntu0.13.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `page_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `page_path` varchar(512) DEFAULT NULL,
  `page_path_hash` varchar(512) DEFAULT NULL,
  `page_text` text,
  `page_author` int(11) DEFAULT NULL,
  `page_categories` varchar(255) DEFAULT NULL,
  `page_keywords` varchar(255) DEFAULT NULL,
  `page_description` text,
  `page_tags` varchar(255) DEFAULT NULL,
  `page_layout` varchar(255) DEFAULT NULL,
  `page_theme` varchar(255) DEFAULT NULL,
  `page_views` int(11) DEFAULT NULL,
  `page_status` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `order_variable` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `OCDT` datetime DEFAULT NULL,
  `OCU` int(10) unsigned DEFAULT NULL,
  `OMDT` datetime DEFAULT NULL,
  `OMU` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Home','/','6666cd76f96956469e7be39d750cc7d9','<p>[P:Timestamp|Format=Y]</p>\n<p>Nesciunt cliche \'\'officia\'\'  ennui ethnic iPhone leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.</p>\n=Erfan\'s Heading=\n[Image:image.jpg|Hoola=YES|Channel=C]\n\n<p>Pug semiotics pour-over, keytar \'\'\'Brooklyn\'\'\' stumptown artisan Terry Richardson tofu fingerstache.</p>\n[Image:sample_A.png|Channel=A] [Image:sample_B.png|Channel=B|Width=800|Description=Hello Kitty]\n<p>Cupidatat  veniam keffiyeh chambray culpa.  Pour-over messenger bag Brooklyn thundercats id, sustainable ullamco.  Dreamcatcher meh typewriter sriracha, velit  forage seitan.</p>\n[Audio:audio.mp3|Channel=B]\n---\n[S:Page 5]\nAuthor is [P:Author]\n<p>Nesciunt cliche officia  ennui ethnic \'\'\'\'\'iPhone\'\'\'\'\' leggings, nisi banjo keytar.  Gentrify nulla  elit Schlitz kale chips shabby chic.  Bicycle rights cred artisan polaroid.</p>\n[File:TheBookOfTheDead.pdf|Channel=D|This is Book of the dead]\n[Video:video.mp4|Autoplay=Yes|Channel=C]',1,'Stories, Place holder','iPhone, Keytar, Artisan','<p>Nesciunt cliche officia  ennui ethnic iPhone leggings, nisi banjo keytar...</p>','Lorem, Ipsum, Dolor, Sit','test.html','',9256,'published','Lorem-Ipsum',7,0,'2013-08-03 17:19:56',0,NULL,NULL),(2,'Page 1','Page1/','69eb7232518d006abe5246e0b99780fa','<span class=\"label\">This is Page 1 <br/>[Image:ABC.png] \n[Image:Hello_Kitty.png|Channel=A]</span>',1,'Stories','A, B, C','<p>This is description...</p>','Tag1, Tag2, Tag3','index.html','cool',4365,'published','Page1',6,0,'2013-08-05 17:20:15',0,NULL,NULL),(3,'Page 2','Page2/','94009e61401b9d8ac834754ba677a4ba','<span class=\"label label-important\">This is Page 2 <br/>[Image:ABC.png]</span>',1,'Stories','A, B, C','<p>This is description...</p>','Tag1, Tag2, Tag3','','',654,'published','Page2',5,0,'2013-08-06 17:20:15',0,NULL,NULL),(4,'Page 3','Page3/','c4dedf5beedb537810142ce50ea8e6e6','<span class=\"label label-info\">This is Page 3 <br/>[Image:ABC.png]</span>',1,'Stories','A, B, C','<p>This is description...</p>','Tag1, Tag2, Tag3','','',1258,'published','Page3',4,0,'2013-08-01 17:20:18',0,NULL,NULL),(5,'Page 4','Page4/','2ebe38e2bda5d96caf5fa9b7621448d3','<span class=\"label label-success\">This is Page 4 <br/>[Image:ABC.png]</span>\n-8<-\nI am on the next printed page :)',1,'Stories','A, B, C','<p>This is description...</p>','Tag1, Tag2, Tag3','','',2877,'published','Page4',3,0,'2013-08-03 17:20:19',0,NULL,NULL),(7,'Wiki','Wiki/','cce7fd0909c5af5ea68ffa6bf55a8aed','<ul>\n	<li>item1</li>\n	<li>item2</li>\n	<li>item3</li>\n	<li>item4</li>\n	<li>item5</li>\n</ul>\n\nLo-fi deep v art party, Vice pour-over pickled sunt.  [[Direct]] trade  cred sint  laboris  master cleanse, mixtape Schlitz.  Duis  gluten-free polaroid nesciunt, Williamsburg forage sint  church-key deserunt  organic chambray sriracha pour-over.  Flexitarian irure  retro VHS.  Id  artisan asymmetrical meggings direct trade  banjo whatever tempor, exercitation craft beer mixtape fingerstache tumblr sriracha Williamsburg.  Mumblecore selvage pariatur, thundercats leggings post-ironic typewriter ut trust fund minim cray duis.  Flannel art party church-key Odd Future.\n\n---\nEu  ea id  church-key, fanny pack culpa  +1 nesciunt asymmetrical mustache Bushwick.  Thundercats nihil Terry Richardson master cleanse eu, dreamcatcher church-key aliqua quinoa gluten-free aesthetic quis magna put a bird on it Wes Anderson.  Butcher sapiente et Godard voluptate  hella, tousled lo-fi ea mixtape sunt mumblecore fanny pack single-origin coffee polaroid.  Swag mumblecore trust fund Tonx, chambray fugiat  laborum.  Banjo iPhone selfies wayfarers duis.  Ut Carles minim, actually trust fund street art beard salvia fashion axe selvage kogi put a bird on it placeat.  Tempor pour-over odio hashtag.\n\n-8<-\n==Important Header==\nAesthetic aute  ut, Carles butcher fingerstache blue bottle.  Brunch ea assumenda, art party asymmetrical Tonx mumblecore excepteur  typewriter ethnic.  Nesciunt actually artisan, yr DIY eu  PBR cray post-ironic tofu exercitation small batch ea voluptate  cliche.  Kitsch farm-to-table stumptown lomo wayfarers cardigan.  DIY scenester you probably haven\'t heard of them gluten-free plaid forage excepteur  est  pork belly, disrupt odio.  Authentic sunt Odd Future, Tonx commodo meggings dreamcatcher ugh.  Do occupy thundercats magna, deserunt  vinyl proident authentic umami Banksy bicycle rights exercitation.\n[http://www.google.com]\nBicycle rights dolor  flexitarian pork belly banh mi minim.  Selvage Neutra VHS letterpress, gentrify pop-up american apparel odio.  Shabby chic ullamco blog cillum  exercitation letterpress, stumptown do shoreditch try-hard bitters veniam.  Scenester adipisicing vero gastropub blog, delectus tumblr photo booth deep v wolf aliqua butcher master cleanse.  Selvage Godard leggings ethical pop-up street art, banh mi officia.  Direct trade  sartorial excepteur  salvia pariatur, retro dolore flannel Brooklyn bitters farm-to-table fap 8-bit.  Art party cred post-ironic, deserunt  authentic narwhal tote bag mustache intelligentsia selfies viral selvage cupidatat.\n\nShoreditch yr Terry Richardson sartorial, pop-up incididunt excepteur  roof party wolf umami ullamco.  Umami twee reprehenderit, laboris  pitchfork chillwave meh keffiyeh artisan banjo mustache elit.  Shoreditch Austin do, sapiente plaid flannel photo booth.  Scenester pork belly Echo Park, anim  Austin mumblecore wayfarers ugh art party pour-over bicycle rights post-ironic.  Literally lomo ad, seitan bicycle rights selvage lo-fi.  Ethical forage ut, 3 wolf moon direct trade  Vice bespoke vegan yr brunch Portland nulla  id  YOLO Neutra.  Sustainable selvage irure  proident squid gastropub exercitation.\n\n---\n[S:Home]',NULL,NULL,NULL,NULL,NULL,'plain.html',NULL,1000,'published','Wiki',2,0,'2013-08-03 17:20:19',0,NULL,NULL),(6,'Page 5','Page5/','00c70b96a3ed98ad82b53352cd9d093b','<span class=\"label label-inverse\">This is Page 5 <br/>[Image:ABC.png]</span>',1,'Stories','A, B, C','<p>This is description...</p>','Tag1, Tag2, Tag3','','',2877,'published','Page5',3,0,'2013-08-03 17:20:19',0,NULL,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-10 16:11:32
